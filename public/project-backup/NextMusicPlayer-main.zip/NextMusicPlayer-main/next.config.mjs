/** @type {import('next').NextConfig} */
const nextConfig = {};

module.exports = {
    allowedDevOrigins: ['http://basic-trackbacks.gl.at.ply.gg'],
  }

export default nextConfig;
